﻿using System;
using System.Collections.Generic;
using System.Text;


public enum WorkingMode
{
    Full,
    Half,
    Energy
}