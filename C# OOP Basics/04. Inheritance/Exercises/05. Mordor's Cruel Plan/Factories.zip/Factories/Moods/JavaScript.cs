﻿namespace _05.Mordor_s_Cruelty_Plan.Factories.Moods
{
    public class JavaScript : Mood
    {
        public JavaScript(int happinessPoints) : base(happinessPoints)
        {
        }
    }
}
