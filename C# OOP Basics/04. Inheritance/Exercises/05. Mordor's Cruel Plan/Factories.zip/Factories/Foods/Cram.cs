﻿namespace _05.Mordor_s_Cruelty_Plan.Factories.Foods
{
    public class Cram : Food
    {
        private const int PointsOfHappiness = 2;

        public Cram() : base(PointsOfHappiness)
        {
        }
    }
}
