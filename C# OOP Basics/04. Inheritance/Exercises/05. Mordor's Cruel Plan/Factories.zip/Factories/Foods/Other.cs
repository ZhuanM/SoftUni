﻿namespace _05.Mordor_s_Cruelty_Plan.Factories.Foods
{
    public class Other : Food
    {
        private new const int PointsOfHappiness = -1;

        public Other() : base(PointsOfHappiness)
        {
        }
    }
}
