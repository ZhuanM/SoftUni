﻿using System;
using System.Collections.Generic;
using System.Text;

public class StandardEmployee : Employee
{
    public StandardEmployee(string name) 
        : base(name, 40)
    {
    }
}