﻿using System;


[SoftUni("Ventsi")] // SoftUniAttribute = SoftUni ~ the IDE says it's unnecessary to add Attribute at the end as it's obvious
class StartUp
{
    [SoftUni("Gosho")] // SoftUniAttribute = SoftUni ~ the IDE says it's unnecessary to add Attribute at the end as it's obvious
    static void Main(string[] args)
    {
        Tracker.PrintMethodsByAuthor();
    }
}
