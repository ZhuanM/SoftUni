﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IGem
{
    int Strength { get; }

    int Agility { get; }

    int Vitality { get; }
}